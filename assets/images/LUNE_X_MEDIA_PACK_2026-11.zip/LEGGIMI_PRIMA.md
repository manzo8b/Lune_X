# LUNE_X — Mini-player audio e immagini promozionali

Pacchetto media per il sito GitHub Pages: https://manzo8b.github.io/Lune_X/

## Contenuto

La cartella `assets/audio` contiene tre estratti originali stereo MP3 da 28 secondi:

| Brano | Estratto del WAV di origine | File pronto |
| --- | --- | --- |
| Frattura Notturna | 00:45–01:13 | `frattura-notturna-preview.mp3` |
| In The Dark We See | 00:45–01:13 | `in-the-dark-we-see-preview.mp3` |
| Next Stop: Torromolinos I | 00:43–01:11 | `next-stop-torremolinos-preview.mp3` |

I file hanno bitrate 160 kbps, sono stereo, usano piccoli fade in/out e non sono soggetti a riproduzione automatica.

La cartella `assets/images` contiene tre immagini WebP ottimizzate:

- `eclipse-dual-billboard.webp` (concept promozionale cartellone)
- `dark-desire-cassette.webp` (concept promozionale cassetta)
- `welcome-to-paradise-promo.webp` (poster estivo)

**Questi mockup non attestano una campagna pubblicitaria reale né la commercializzazione di supporti fisici.**

## Come inserirli in GitHub

1. Apri il repository: https://github.com/manzo8b/Lune_X
2. Apri la cartella `assets/audio`. Clicca **Add file → Upload files**; trascina i tre MP3 estratti dalla cartella `assets/audio` di questo ZIP. Conferma **Commit changes**.
3. Torna al repository e apri `assets/images`. Clicca **Add file → Upload files**; trascina i tre WebP estratti dalla cartella `assets/images` di questo ZIP. Conferma **Commit changes**.
4. Aspetta che GitHub Actions finisca il deployment: https://github.com/manzo8b/Lune_X/actions
5. Apri https://manzo8b.github.io/Lune_X/ e ricarica la pagina: i tre player e le tre foto si attivano automaticamente. Il sito verifica prima che i file esistano; se mancano, mostra un messaggio corretto e non un player finto.

**Non caricare lo ZIP come singolo file nel repository**: GitHub Pages non estrae automaticamente archivi ZIP. È necessario caricare i sei file nelle due cartelle previste.

## Note sui diritti

Pubblica soltanto estratti musicali di cui sei titolare o che hai diritto di distribuire direttamente. Se usi un servizio generativo per produrre i brani, verifica che il piano e le condizioni di licenza applicabili consentano questa pubblicazione sul tuo sito.
